
--
-- Dumping data for table `vehicle_model`
--

INSERT INTO `vehicle_model` (`id`, `model_name`, `make`, `user_id`, `changed`) VALUES
(1, 'Focus', 3, 1, '2020-05-09 10:14:21'),
(2, 'Jazz', 5, 1, '2020-05-09 10:14:55');
