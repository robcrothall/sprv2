
--
-- Dumping data for table `vehicle_make`
--

INSERT INTO `vehicle_make` (`id`, `manufacturer`, `user_id`, `changed`) VALUES
(1, 'Audi', 1, '2020-05-09 10:12:10'),
(2, 'BMW', 1, '2020-05-09 10:12:10'),
(3, 'Ford', 1, '2020-05-09 10:12:44'),
(4, 'Volkswagen', 1, '2020-05-09 10:12:44'),
(5, 'Honda', 1, '2020-05-09 10:13:14'),
(6, 'Mercedes Benz', 1, '2020-05-09 10:13:14');
