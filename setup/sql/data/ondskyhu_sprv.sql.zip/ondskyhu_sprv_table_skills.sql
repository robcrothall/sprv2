
--
-- Dumping data for table `skills`
--

INSERT INTO `skills` (`id`, `skill_name`, `user_id`, `changed`) VALUES
(1, 'Finance', 1, '2020-05-09 09:47:26'),
(2, 'Management', 1, '2020-05-09 09:47:26'),
(3, 'Project Management', 1, '2020-05-09 09:47:58'),
(4, 'Woodwork', 1, '2020-05-09 09:47:58');
