
--
-- Dumping data for table `asset_phone`
--

INSERT INTO `asset_phone` (`id`, `asset_id`, `phone`, `descr`, `account_no`, `user_id`, `changed`) VALUES
(1, 353, '046 604 0371', '', '', 1, '2021-05-23 14:36:57'),
(2, 347, '046 604 0446', 'Security gate house', '', 1, '2021-05-23 14:39:31'),
(3, 346, '046 604 0501', 'Swimming pool', '', 1, '2021-05-23 14:42:11'),
(4, 355, '046 604 0524', 'Village Clinic', '', 1, '2021-05-23 14:43:26'),
(5, 355, '046 604 0529', 'Duty Room', '', 1, '2021-05-23 14:44:36'),
(6, 355, '046 604 0531', 'Assisted Living Lounge', '', 1, '2021-05-23 14:45:42');
