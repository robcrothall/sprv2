
--
-- Dumping data for table `asset_type`
--

INSERT INTO `asset_type` (`id`, `description`, `user_id`, `changed`) VALUES
(1, 'Cottage', 1, '2020-05-09 07:25:51'),
(2, 'Care Centre Room', 1, '2020-05-09 07:25:51'),
(3, 'Building', 1, '2020-05-09 07:26:59'),
(4, 'Vehicle', 1, '2020-05-09 07:26:59'),
(5, 'Garage', 1, '2020-05-09 07:48:13'),
(6, 'Workshop', 1, '2020-05-09 07:48:13'),
(7, 'Pump', 1, '2020-07-01 22:00:03');
