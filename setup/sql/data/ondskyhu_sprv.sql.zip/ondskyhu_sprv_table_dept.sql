
--
-- Dumping data for table `dept`
--

INSERT INTO `dept` (`id`, `dept_name`, `dept_manager_id`, `job_email`, `user_id`, `changed`) VALUES
(1, 'General Manager', 1081, 'gm@settlerspark.co.za', 1, '2021-01-13 13:18:31'),
(2, 'Systems and Administration', 522, 'irene@settlerspark.co.za', 1, '2021-01-13 13:19:07'),
(3, 'Sales', 512, 'sue@settlerspark.co.za', 1, '2021-01-13 13:19:25'),
(4, 'Finance', 513, 'kittie@settlerspark.co.za', 1, '2021-01-13 13:19:49'),
(5, 'Care Centre', 569, 'sr-erica@settlerspark.co.za', 1, '2021-06-25 14:49:11'),
(6, 'Facilities', 599, '', 1, '2021-03-17 13:35:44'),
(7, 'Hibiscus Room', 528, 'danielle@settlerspark.co.za', 1, '2021-01-13 13:21:17'),
(8, 'Gardens', 599, '', 1, '2021-03-17 13:35:29'),
(9, 'Projects', 260, 'rob@crothall.co.za', 1, '2021-10-19 14:20:26');
