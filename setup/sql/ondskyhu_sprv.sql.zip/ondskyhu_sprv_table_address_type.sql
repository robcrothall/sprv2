
--
-- Dumping data for table `address_type`
--

INSERT INTO `address_type` (`id`, `addr_type`, `user_id`, `changed`) VALUES
(1, 'Physical', 1, '2020-05-09 08:24:56'),
(2, 'Postal', 1, '2020-05-09 08:24:28'),
(3, 'Delivery', 1, '2022-01-11 08:53:04');
